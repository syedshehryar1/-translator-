//#region node_modules/.nitro/vite/services/ssr/assets/languages-BVFdgPVV.js
var AUTO = {
	code: "auto",
	name: "Detect language",
	native: "Auto",
	bcp47: "en",
	latin: true
};
var LANGUAGES = [
	{
		code: "en",
		name: "English",
		native: "English",
		bcp47: "en-US",
		latin: true
	},
	{
		code: "ur",
		name: "Urdu",
		native: "اردو",
		rtl: true,
		bcp47: "ur-PK",
		latin: false
	},
	{
		code: "hi",
		name: "Hindi",
		native: "हिन्दी",
		bcp47: "hi-IN",
		latin: false
	},
	{
		code: "ar",
		name: "Arabic",
		native: "العربية",
		rtl: true,
		bcp47: "ar-SA",
		latin: false
	},
	{
		code: "pa",
		name: "Punjabi",
		native: "پنجابی",
		rtl: true,
		bcp47: "pa-PK",
		latin: false
	},
	{
		code: "fa",
		name: "Persian",
		native: "فارسی",
		rtl: true,
		bcp47: "fa-IR",
		latin: false
	},
	{
		code: "ps",
		name: "Pashto",
		native: "پښتو",
		rtl: true,
		bcp47: "ps-AF",
		latin: false
	},
	{
		code: "sd",
		name: "Sindhi",
		native: "سنڌي",
		rtl: true,
		bcp47: "sd-PK",
		latin: false
	},
	{
		code: "bn",
		name: "Bengali",
		native: "বাংলা",
		bcp47: "bn-BD",
		latin: false
	},
	{
		code: "tr",
		name: "Turkish",
		native: "Türkçe",
		bcp47: "tr-TR",
		latin: true
	},
	{
		code: "es",
		name: "Spanish",
		native: "Español",
		bcp47: "es-ES",
		latin: true
	},
	{
		code: "fr",
		name: "French",
		native: "Français",
		bcp47: "fr-FR",
		latin: true
	},
	{
		code: "de",
		name: "German",
		native: "Deutsch",
		bcp47: "de-DE",
		latin: true
	},
	{
		code: "pt",
		name: "Portuguese",
		native: "Português",
		bcp47: "pt-BR",
		latin: true
	},
	{
		code: "it",
		name: "Italian",
		native: "Italiano",
		bcp47: "it-IT",
		latin: true
	},
	{
		code: "ru",
		name: "Russian",
		native: "Русский",
		bcp47: "ru-RU",
		latin: false
	},
	{
		code: "zh",
		name: "Chinese",
		native: "中文",
		bcp47: "zh-CN",
		latin: false
	},
	{
		code: "ja",
		name: "Japanese",
		native: "日本語",
		bcp47: "ja-JP",
		latin: false
	},
	{
		code: "ko",
		name: "Korean",
		native: "한국어",
		bcp47: "ko-KR",
		latin: false
	},
	{
		code: "id",
		name: "Indonesian",
		native: "Bahasa Indonesia",
		bcp47: "id-ID",
		latin: true
	},
	{
		code: "nl",
		name: "Dutch",
		native: "Nederlands",
		bcp47: "nl-NL",
		latin: true
	},
	{
		code: "pl",
		name: "Polish",
		native: "Polski",
		bcp47: "pl-PL",
		latin: true
	},
	{
		code: "vi",
		name: "Vietnamese",
		native: "Tiếng Việt",
		bcp47: "vi-VN",
		latin: true
	},
	{
		code: "th",
		name: "Thai",
		native: "ไทย",
		bcp47: "th-TH",
		latin: false
	},
	{
		code: "ta",
		name: "Tamil",
		native: "தமிழ்",
		bcp47: "ta-IN",
		latin: false
	},
	{
		code: "sw",
		name: "Swahili",
		native: "Kiswahili",
		bcp47: "sw-KE",
		latin: true
	},
	{
		code: "he",
		name: "Hebrew",
		native: "עברית",
		rtl: true,
		bcp47: "he-IL",
		latin: false
	},
	{
		code: "el",
		name: "Greek",
		native: "Ελληνικά",
		bcp47: "el-GR",
		latin: false
	},
	{
		code: "uk",
		name: "Ukrainian",
		native: "Українська",
		bcp47: "uk-UA",
		latin: false
	},
	{
		code: "ro",
		name: "Romanian",
		native: "Română",
		bcp47: "ro-RO",
		latin: true
	}
];
var POPULAR_CODES = [
	"en",
	"ur",
	"hi",
	"ar",
	"es",
	"fr",
	"de",
	"zh",
	"tr",
	"fa"
];
function getLanguage(code) {
	if (code === "auto") return AUTO;
	return LANGUAGES.find((l) => l.code === code) ?? LANGUAGES[0];
}
var MAX_CHARS = 2e3;
//#endregion
export { getLanguage as a, POPULAR_CODES as i, LANGUAGES as n, MAX_CHARS as r, AUTO as t };
