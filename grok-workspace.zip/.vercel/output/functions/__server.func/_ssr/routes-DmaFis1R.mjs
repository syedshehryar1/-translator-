import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
import { a as Search, c as History, d as ChevronDown, f as Check, l as Eraser, n as VolumeX, o as LoaderCircle, p as ArrowLeftRight, r as Volume2, s as Languages, t as X, u as Copy } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as getLanguage, i as POPULAR_CODES, n as LANGUAGES, r as MAX_CHARS, t as AUTO } from "./languages-BVFdgPVV.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as Slot } from "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/@radix-ui/react-popover+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DmaFis1R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pine", {
	variants: {
		variant: {
			primary: "bg-pine text-pine-fg hover:opacity-90",
			secondary: "bg-surface-2 text-ink hover:bg-line",
			ghost: "text-muted hover:text-ink hover:bg-surface-2",
			outline: "paper-shadow bg-surface text-ink hover:shadow-[var(--shadow-border-hover)]"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-lg",
			md: "h-11 px-4 text-sm rounded-xl",
			lg: "h-12 px-5 text-base rounded-xl",
			icon: "size-11 rounded-xl",
			iconSm: "size-9 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function LanguagePicker({ value, onChange, includeAuto = false, align = "start", searchPlaceholder = "Search languages" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const inputRef = (0, import_react.useRef)(null);
	const current = includeAuto && value === "auto" ? AUTO : getLanguage(value);
	const nativeShown = current.native !== current.name && current.code !== "auto";
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		const pool = includeAuto ? [AUTO, ...LANGUAGES] : LANGUAGES;
		if (!q) return pool;
		return pool.filter((l) => l.name.toLowerCase().includes(q) || l.native.toLowerCase().includes(q) || l.code.toLowerCase().includes(q));
	}, [query, includeAuto]);
	const popular = includeAuto ? [AUTO, ...POPULAR_CODES.map((c) => getLanguage(c))] : POPULAR_CODES.map((c) => getLanguage(c));
	const rest = (0, import_react.useMemo)(() => {
		const popularCodes = new Set(popular.map((l) => l.code));
		return (includeAuto ? [AUTO, ...LANGUAGES] : LANGUAGES).filter((l) => !popularCodes.has(l.code));
	}, [includeAuto, popular]);
	(0, import_react.useEffect)(() => {
		if (open) {
			setQuery("");
			const t = window.setTimeout(() => inputRef.current?.focus(), 30);
			return () => window.clearTimeout(t);
		}
	}, [open]);
	function choose(code) {
		onChange(code);
		setOpen(false);
	}
	const list = query ? filtered : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root2, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: cn("inline-flex h-11 max-w-full min-w-0 items-center gap-2 rounded-xl px-3", "text-left text-sm font-medium text-ink", "hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pine", "transition-[background-color,transform] duration-150 ease-out active:scale-[0.96]"),
				"aria-label": current.name,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex min-w-0 items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: current.name
					}), nativeShown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("truncate font-normal text-muted", current.rtl && "font-arabic"),
						children: current.native
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-4 shrink-0 text-muted transition-transform duration-150", open && "rotate-180"),
					strokeWidth: 1.75
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Content2, {
			align,
			sideOffset: 8,
			collisionPadding: 12,
			className: "z-50 w-80 origin-top rounded-2xl bg-surface p-2 paper-shadow",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					className: "pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-subtle",
					strokeWidth: 1.75
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: inputRef,
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: searchPlaceholder,
					className: "h-11 w-full rounded-xl bg-surface-2 ps-10 pe-3 text-sm text-ink outline-none placeholder:text-subtle focus:ring-2 focus:ring-pine/30"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-72 overflow-y-auto overscroll-contain",
				children: list ? list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-6 text-center text-sm text-muted",
					children: "No languages match"
				}) : list.map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangRow, {
					lang,
					selected: lang.code === value,
					onSelect: choose
				}, lang.code)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-1 px-2 pt-1 text-xs font-medium tracking-wide text-subtle",
						children: "Popular"
					}),
					popular.map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangRow, {
						lang,
						selected: lang.code === value,
						onSelect: choose
					}, `p-${lang.code}`)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-1 px-2 pt-2 text-xs font-medium tracking-wide text-subtle",
						children: "All"
					}),
					rest.map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangRow, {
						lang,
						selected: lang.code === value,
						onSelect: choose
					}, lang.code))
				] })
			})]
		}) })]
	});
}
function LangRow({ lang, selected, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onSelect(lang.code),
		className: cn("flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-start text-sm transition-colors duration-150", selected ? "bg-pine/10 text-ink" : "text-ink hover:bg-surface-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate font-medium",
				children: lang.name
			}), lang.native !== lang.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("block truncate text-xs text-muted", lang.rtl && "font-arabic"),
				dir: lang.rtl ? "rtl" : "ltr",
				children: lang.native
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate text-xs text-muted",
				children: lang.code
			})]
		}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: "size-4 shrink-0 text-pine",
			strokeWidth: 2
		}) : null]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var InputSchema = object({
	text: string().trim().min(1).max(MAX_CHARS),
	source: string().min(2).max(16),
	target: string().min(2).max(16),
	tone: _enum([
		"natural",
		"formal",
		"casual"
	])
});
var translateText = createServerFn({ method: "POST" }).validator((input) => InputSchema.parse(input)).handler(createSsrRpc("5a82a487ec2f76fe951e4717718e8de908e24c3c78e7fc11294310fd9edc4635"));
var HISTORY_KEY = "lisan-history";
var PREFS_KEY = "lisan-prefs";
var DEFAULT_PREFS = {
	source: "en",
	target: "ur",
	tone: "natural",
	ui: "en"
};
function loadHistory() {
	try {
		const raw = localStorage.getItem(HISTORY_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.slice(0, 40);
	} catch {
		return [];
	}
}
function saveHistory(items) {
	localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 40)));
}
function loadPrefs() {
	try {
		const raw = localStorage.getItem(PREFS_KEY);
		if (!raw) return DEFAULT_PREFS;
		const parsed = JSON.parse(raw);
		return {
			source: parsed.source ?? DEFAULT_PREFS.source,
			target: parsed.target ?? DEFAULT_PREFS.target,
			tone: parsed.tone === "formal" || parsed.tone === "casual" ? parsed.tone : "natural",
			ui: parsed.ui === "ur" ? "ur" : "en"
		};
	} catch {
		return DEFAULT_PREFS;
	}
}
function savePrefs(prefs) {
	localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
}
var TONES = [
	{
		id: "natural",
		en: "Natural",
		ur: "قدرتی"
	},
	{
		id: "formal",
		en: "Formal",
		ur: "رسمی"
	},
	{
		id: "casual",
		en: "Casual",
		ur: "دوستانہ"
	}
];
var COPY = {
	en: {
		translator: "Translator",
		translate: "Translate",
		source: "From",
		target: "To",
		placeholder: "Type or paste text",
		empty: "Translation appears here",
		history: "History",
		emptyHistory: "Your recent translations will live here.",
		copy: "Copy",
		copied: "Copied",
		listen: "Listen",
		stop: "Stop",
		clear: "Clear",
		swap: "Swap languages",
		examples: "Try",
		shortcut: "⌘ Enter",
		shortcutWin: "Ctrl Enter",
		romanization: "Romanization",
		detected: "Detected",
		error: "Something went wrong",
		uiEn: "EN",
		uiUr: "اردو",
		clearHistory: "Clear all"
	},
	ur: {
		translator: "مترجم",
		translate: "ترجمہ کریں",
		source: "سے",
		target: "میں",
		placeholder: "متن لکھیں یا چسپاں کریں",
		empty: "ترجمہ یہاں نظر آئے گا",
		history: "تاریخ",
		emptyHistory: "حالیہ ترجمے یہاں محفوظ ہوں گے۔",
		copy: "کاپی",
		copied: "کاپی ہو گیا",
		listen: "سنیں",
		stop: "روکیں",
		clear: "صاف",
		swap: "زبانیں بدلیں",
		examples: "مثال",
		shortcut: "⌘ Enter",
		shortcutWin: "Ctrl Enter",
		romanization: "رومن",
		detected: "پہچانی گئی",
		error: "ترجمہ نہیں ہو سکا",
		uiEn: "EN",
		uiUr: "اردو",
		clearHistory: "سب مٹائیں"
	}
};
var EXAMPLES = [
	{
		text: "How are you?",
		source: "en",
		target: "ur",
		label: "How are you?"
	},
	{
		text: "آج موسم بہت خوبصورت ہے۔",
		source: "ur",
		target: "en",
		label: "آج موسم…"
	},
	{
		text: "Let's meet tomorrow at five.",
		source: "en",
		target: "hi",
		label: "Let's meet…"
	}
];
function TranslatorApp() {
	const [prefs, setPrefs] = (0, import_react.useState)(DEFAULT_PREFS);
	const [sourceText, setSourceText] = (0, import_react.useState)("");
	const [translation, setTranslation] = (0, import_react.useState)("");
	const [romanization, setRomanization] = (0, import_react.useState)(null);
	const [detected, setDetected] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [historyOpen, setHistoryOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [speaking, setSpeaking] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [isMac, setIsMac] = (0, import_react.useState)(false);
	const requestId = (0, import_react.useRef)(0);
	const skipNextLangEffect = (0, import_react.useRef)(true);
	const lastKey = (0, import_react.useRef)("");
	const cache = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const t = COPY[prefs.ui];
	const rtlUi = prefs.ui === "ur";
	const sourceLang = prefs.source === "auto" ? AUTO : getLanguage(prefs.source);
	const targetLang = getLanguage(prefs.target);
	(0, import_react.useEffect)(() => {
		setPrefs(loadPrefs());
		setHistory(loadHistory());
		setHydrated(true);
		setIsMac(/Mac|iPhone|iPad/.test(navigator.platform));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		savePrefs(prefs);
	}, [prefs, hydrated]);
	const runTranslate = (0, import_react.useCallback)(async (text, source, target, tone) => {
		const trimmed = text.trim();
		if (!trimmed) return;
		const key = `${source}|${target}|${tone}|${trimmed}`;
		const cached = cache.current.get(key);
		if (cached) {
			lastKey.current = key;
			setTranslation(cached.translation);
			setRomanization(cached.romanization);
			setDetected(cached.detected);
			setError(null);
			return;
		}
		const id = ++requestId.current;
		setLoading(true);
		setError(null);
		try {
			const result = await translateText({ data: {
				text: trimmed,
				source,
				target,
				tone
			} });
			if (id !== requestId.current) return;
			if (!result.ok) {
				setError(result.error);
				return;
			}
			lastKey.current = key;
			cache.current.set(key, {
				translation: result.translation,
				romanization: result.romanization,
				detected: result.detectedSource
			});
			setTranslation(result.translation);
			setRomanization(result.romanization);
			setDetected(result.detectedSource);
			const item = {
				id: `${Date.now()}`,
				sourceText: trimmed,
				translation: result.translation,
				source,
				target,
				tone,
				at: Date.now()
			};
			setHistory((prev) => {
				const next = [item, ...prev.filter((h) => !(h.sourceText === trimmed && h.source === source && h.target === target))].slice(0, 40);
				saveHistory(next);
				return next;
			});
		} catch {
			if (id !== requestId.current) return;
			setError(COPY[prefs.ui].error);
		} finally {
			if (id === requestId.current) setLoading(false);
		}
	}, [prefs.ui]);
	(0, import_react.useEffect)(() => {
		if (skipNextLangEffect.current) {
			skipNextLangEffect.current = false;
			return;
		}
		if (!sourceText.trim() || !translation) return;
		runTranslate(sourceText, prefs.source, prefs.target, prefs.tone);
	}, [
		prefs.source,
		prefs.target,
		prefs.tone
	]);
	function updatePrefs(patch) {
		setPrefs((p) => ({
			...p,
			...patch
		}));
	}
	function onSwap() {
		skipNextLangEffect.current = true;
		updatePrefs({
			source: prefs.source === "auto" ? prefs.target : prefs.target,
			target: prefs.source === "auto" ? detected?.code && detected.code !== prefs.target ? detected.code : "en" : prefs.source
		});
		setSourceText(translation);
		setTranslation(sourceText);
		setRomanization(null);
		setDetected(null);
	}
	function onClear() {
		requestId.current += 1;
		setSourceText("");
		setTranslation("");
		setRomanization(null);
		setDetected(null);
		setError(null);
		setLoading(false);
	}
	async function onCopy() {
		if (!translation) return;
		try {
			await navigator.clipboard.writeText(translation);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {}
	}
	function onSpeak() {
		if (!translation || typeof window === "undefined" || !window.speechSynthesis) return;
		if (speaking) {
			window.speechSynthesis.cancel();
			setSpeaking(false);
			return;
		}
		window.speechSynthesis.cancel();
		const utter = new SpeechSynthesisUtterance(translation);
		utter.lang = targetLang.bcp47;
		utter.onend = () => setSpeaking(false);
		utter.onerror = () => setSpeaking(false);
		setSpeaking(true);
		window.speechSynthesis.speak(utter);
	}
	function restoreItem(item) {
		skipNextLangEffect.current = true;
		updatePrefs({
			source: item.source,
			target: item.target,
			tone: item.tone
		});
		setSourceText(item.sourceText);
		setTranslation(item.translation);
		setRomanization(null);
		setDetected(null);
		setHistoryOpen(false);
	}
	const shortcut = isMac ? t.shortcut : t.shortcutWin;
	const charCount = sourceText.length;
	const canTranslate = sourceText.trim().length > 0 && !loading;
	const sourceDir = sourceLang.rtl ? "rtl" : "ltr";
	const targetDir = targetLang.rtl ? "rtl" : "ltr";
	const sourceFont = sourceLang.rtl || sourceLang.code === "ur";
	const targetFont = targetLang.rtl || targetLang.code === "ur";
	const detectedLabel = (0, import_react.useMemo)(() => {
		if (prefs.source !== "auto" || !detected) return null;
		return `${t.detected}: ${detected.name}`;
	}, [
		prefs.source,
		detected,
		t.detected
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: rtlUi ? "rtl" : "ltr",
		className: "relative mx-auto flex min-h-dvh max-w-6xl flex-col px-4 pb-16 pt-6 sm:px-6 sm:pt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "enter-up mb-8 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-xl bg-pine text-pine-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, {
							className: "size-5",
							strokeWidth: 1.75
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-medium tracking-tight text-ink italic",
							children: "Lisan"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-arabic text-lg text-muted",
							dir: "rtl",
							children: "لسان"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t.translator
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-xl bg-surface-2 p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => updatePrefs({ ui: "en" }),
							className: cn("h-9 rounded-lg px-3 text-xs font-medium transition-colors duration-150", prefs.ui === "en" ? "bg-surface text-ink paper-shadow" : "text-muted hover:text-ink"),
							children: t.uiEn
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => updatePrefs({ ui: "ur" }),
							className: cn("h-9 rounded-lg px-3 font-arabic text-xs font-medium transition-colors duration-150", prefs.ui === "ur" ? "bg-surface text-ink paper-shadow" : "text-muted hover:text-ink"),
							children: t.uiUr
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": t.history,
						onClick: () => setHistoryOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, {
							className: "size-5",
							strokeWidth: 1.75
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "enter-up enter-up-delay-1 mb-4 flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-subtle",
					children: t.examples
				}), EXAMPLES.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						skipNextLangEffect.current = true;
						updatePrefs({
							source: ex.source,
							target: ex.target
						});
						setSourceText(ex.text);
						runTranslate(ex.text, ex.source, ex.target, prefs.tone);
					},
					className: "h-9 rounded-full bg-surface px-3.5 text-sm text-ink paper-shadow transition-[transform,box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
					children: ex.label
				}, ex.label))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "enter-up enter-up-delay-2 relative grid grid-cols-1 gap-3 lg:grid-cols-[1fr_auto_1fr] lg:items-stretch",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-h-72 flex-col rounded-2xl bg-surface p-3 paper-shadow sm:min-h-80 sm:p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguagePicker, {
									value: prefs.source,
									includeAuto: true,
									searchPlaceholder: rtlUi ? "زبان تلاش کریں" : "Search languages",
									onChange: (code) => {
										if (code === prefs.target) return;
										updatePrefs({ source: code });
									}
								}), detectedLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate pe-2 text-xs text-muted",
									children: detectedLabel
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: sourceText,
								maxLength: MAX_CHARS,
								onChange: (e) => setSourceText(e.target.value),
								onKeyDown: (e) => {
									if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
										e.preventDefault();
										if (canTranslate) runTranslate(sourceText, prefs.source, prefs.target, prefs.tone);
									}
								},
								placeholder: t.placeholder,
								dir: sourceDir,
								className: cn("min-h-44 flex-1 resize-none bg-transparent px-2 py-2 text-lg leading-relaxed text-ink outline-none placeholder:text-subtle", sourceFont && "font-arabic")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between gap-2 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums text-xs text-subtle",
									children: [
										charCount,
										" / ",
										MAX_CHARS
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onClear,
									disabled: !sourceText,
									className: "inline-flex h-9 items-center gap-1.5 rounded-lg px-2 text-xs font-medium text-muted transition-colors hover:text-ink disabled:opacity-40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {
										className: "size-3.5",
										strokeWidth: 1.75
									}), t.clear]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-center gap-3 lg:flex-col",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							"aria-label": t.swap,
							onClick: onSwap,
							className: "bg-surface",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, {
								className: "size-4 lg:rotate-90",
								strokeWidth: 1.75
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-h-72 flex-col rounded-2xl bg-surface p-3 paper-shadow sm:min-h-80 sm:p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-2 flex items-center justify-between gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguagePicker, {
									value: prefs.target,
									align: "end",
									searchPlaceholder: rtlUi ? "زبان تلاش کریں" : "Search languages",
									onChange: (code) => {
										if (code === prefs.source && prefs.source !== "auto") return;
										updatePrefs({ target: code });
									}
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative min-h-44 flex-1 px-2 py-2",
								children: [
									loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3 pt-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "shimmer h-3 w-5/6 rounded-full" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "shimmer h-3 w-2/3 rounded-full" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "shimmer h-3 w-3/4 rounded-full" })
										]
									}) : translation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										dir: targetDir,
										className: cn("whitespace-pre-wrap text-lg leading-relaxed text-ink", targetFont && "font-arabic"),
										children: translation
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg text-subtle",
										children: t.empty
									}),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm text-danger",
										children: error
									}) : null,
									romanization && !loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-4 text-sm italic leading-relaxed text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "not-italic tracking-wide text-subtle uppercase",
												children: t.romanization
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mx-2 text-line",
												children: "/"
											}),
											romanization
										]
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-end gap-1 px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "iconSm",
									"aria-label": speaking ? t.stop : t.listen,
									disabled: !translation,
									onClick: onSpeak,
									children: speaking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
										className: "size-4",
										strokeWidth: 1.75
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
										className: "size-4",
										strokeWidth: 1.75
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "iconSm",
									"aria-label": copied ? t.copied : t.copy,
									disabled: !translation,
									onClick: onCopy,
									children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-4 text-ok",
										strokeWidth: 2
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
										className: "size-4",
										strokeWidth: 1.75
									})
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "enter-up enter-up-delay-3 mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex rounded-xl bg-surface-2 p-1",
					children: TONES.map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => updatePrefs({ tone: tone.id }),
						className: cn("h-10 min-w-20 rounded-lg px-3 text-sm font-medium transition-colors duration-150", prefs.tone === tone.id ? "bg-surface text-ink paper-shadow" : "text-muted hover:text-ink"),
						children: rtlUi ? tone.ur : tone.en
					}, tone.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-subtle sm:inline",
						children: shortcut
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						disabled: !canTranslate,
						onClick: () => void runTranslate(sourceText, prefs.source, prefs.target, prefs.tone),
						className: "min-w-40",
						children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "size-4 animate-spin",
							strokeWidth: 1.75
						}) : null, t.translate]
					})]
				})]
			}),
			historyOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-ink/20",
					"aria-label": "Close history",
					onClick: () => setHistoryOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "relative flex h-full w-full max-w-md flex-col bg-bg p-5 shadow-[var(--shadow-border)]",
					role: "dialog",
					"aria-label": t.history,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl italic",
							children: t.history
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 px-3 text-sm text-muted hover:text-ink",
								onClick: () => {
									setHistory([]);
									saveHistory([]);
								},
								children: t.clearHistory
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: () => setHistoryOpen(false),
								"aria-label": "Close",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									className: "size-5",
									strokeWidth: 1.75
								})
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 overflow-y-auto",
						children: history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-12 text-sm text-muted",
							children: t.emptyHistory
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: history.map((item) => {
								const from = getLanguage(item.source);
								const to = getLanguage(item.target);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => restoreItem(item),
									className: "w-full rounded-2xl bg-surface p-4 text-start paper-shadow transition-[transform,box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-2 text-xs text-subtle",
											children: [
												from.name,
												" → ",
												to.name
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "line-clamp-2 text-sm text-ink",
											children: item.sourceText
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: cn("mt-1 line-clamp-2 text-sm text-muted", to.rtl && "font-arabic"),
											dir: to.rtl ? "rtl" : "ltr",
											children: item.translation
										})
									]
								}) }, item.id);
							})
						})
					})]
				})]
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslatorApp, {});
}
//#endregion
export { Home as component };
