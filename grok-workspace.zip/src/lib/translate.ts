import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getLanguage, LANGUAGES, MAX_CHARS } from "./languages";

const InputSchema = z.object({
  text: z.string().trim().min(1).max(MAX_CHARS),
  source: z.string().min(2).max(16),
  target: z.string().min(2).max(16),
  tone: z.enum(["natural", "formal", "casual"]),
});

export type TranslateSuccess = {
  ok: true;
  translation: string;
  detectedSource: { code: string; name: string };
  romanization: string | null;
};

export type TranslateFailure = {
  ok: false;
  error: string;
};

export type TranslateResult = TranslateSuccess | TranslateFailure;

const ResultSchema = z.object({
  translation: z.string(),
  detectedSource: z.object({
    code: z.string(),
    name: z.string(),
  }),
  romanization: z.string().nullable().optional(),
});

const CODE_ALIASES: Record<string, string> = {
  iw: "he",
  "zh-cn": "zh",
  "zh-tw": "zh",
  "zh-hans": "zh",
  nb: "en",
  fil: "en",
};

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fence?.[1] ?? trimmed;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1) {
    throw new Error("Model returned no JSON");
  }
  return JSON.parse(raw.slice(start, end + 1)) as unknown;
}

function knownCode(code: string): string {
  const lower = code.toLowerCase();
  const aliased = CODE_ALIASES[lower] ?? lower.split("-")[0] ?? lower;
  if (aliased === "auto") return "en";
  if (LANGUAGES.some((l) => l.code === aliased)) return aliased;
  const byName = LANGUAGES.find(
    (l) =>
      l.name.toLowerCase() === aliased || l.native.toLowerCase() === aliased,
  );
  return byName?.code ?? "en";
}

function success(
  translation: string,
  detectedCode: string,
  romanization: string | null,
): TranslateSuccess {
  const code = knownCode(detectedCode);
  return {
    ok: true,
    translation,
    detectedSource: { code, name: getLanguage(code).name },
    romanization,
  };
}

async function translateWithXai(input: {
  text: string;
  source: string;
  target: string;
  tone: "natural" | "formal" | "casual";
}): Promise<TranslateResult | null> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return null;

  const sourceMeta = getLanguage(input.source === "auto" ? "en" : input.source);
  const target = getLanguage(input.target);
  const sourceLabel =
    input.source === "auto"
      ? "auto-detect the source language"
      : `${sourceMeta.name} (${sourceMeta.native})`;

  const system = [
    "You are a precise professional translator.",
    "Return ONLY a JSON object with keys: translation, detectedSource, romanization.",
    "detectedSource: { code: ISO 639-1, name: English name } of the source text.",
    "romanization: Latin transliteration of the translation when the target script is not Latin; otherwise null.",
    "Preserve meaning, register, and line breaks. Do not add notes, quotes, or commentary.",
    "If the text is already in the target language, return it unchanged.",
  ].join(" ");

  const user = [
    `Translate into ${target.name} (${target.native}).`,
    `Source: ${sourceLabel}.`,
    `Tone: ${input.tone} (natural = fluent everyday; formal = polite; casual = colloquial).`,
    "",
    input.text,
  ].join("\n");

  let res: Response;
  try {
    res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.2,
        max_tokens: 1800,
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
      }),
      signal: AbortSignal.timeout(12_000),
    });
  } catch {
    return null;
  }

  if (!res.ok) return null;

  const body = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = body.choices?.[0]?.message?.content ?? "";
  if (!content) return null;

  try {
    const parsed = ResultSchema.parse(extractJson(content));
    const translation = parsed.translation.trim();
    if (!translation) return null;
    return success(
      translation,
      parsed.detectedSource.code,
      parsed.romanization?.trim() || null,
    );
  } catch {
    const fallback = content.replace(/```[\s\S]*?```/g, "").trim();
    if (!fallback) return null;
    return success(
      fallback,
      input.source === "auto" ? "en" : input.source,
      null,
    );
  }
}

function parseChromePayload(
  payload: unknown,
  requestedSource: string,
): { translation: string; detected: string } {
  if (typeof payload === "string") {
    return { translation: payload, detected: requestedSource };
  }
  if (!Array.isArray(payload) || payload.length === 0) {
    throw new Error("Unexpected translation payload");
  }
  const first = payload[0];
  if (typeof first === "string") {
    const maybeLang =
      typeof payload[1] === "string" && payload[1].length <= 8
        ? payload[1]
        : requestedSource;
    return { translation: first, detected: maybeLang };
  }
  if (Array.isArray(first) && typeof first[0] === "string") {
    const lang =
      typeof first[1] === "string" && first[1].length <= 8
        ? first[1]
        : requestedSource;
    return { translation: first[0], detected: lang };
  }
  throw new Error("Unexpected translation payload");
}

async function translateWithChrome(input: {
  text: string;
  source: string;
  target: string;
}): Promise<TranslateResult> {
  const sl = input.source === "auto" ? "auto" : input.source;
  const tl = input.target === "zh" ? "zh-CN" : input.target;
  const url =
    "https://clients5.google.com/translate_a/t?" +
    new URLSearchParams({
      client: "dict-chrome-ex",
      sl,
      tl,
      q: input.text,
    }).toString();

  const res = await fetch(url, {
    headers: {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
      Accept: "application/json",
    },
    signal: AbortSignal.timeout(15_000),
  });

  if (!res.ok) {
    return { ok: false, error: "Could not reach the translator. Try again." };
  }

  const payload: unknown = await res.json();
  const parsed = parseChromePayload(
    payload,
    input.source === "auto" ? "en" : input.source,
  );
  const translation = parsed.translation.trim();
  if (!translation) {
    return { ok: false, error: "Empty translation. Try again." };
  }
  return success(translation, parsed.detected, null);
}

export const translateText = createServerFn({ method: "POST" })
  .validator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<TranslateResult> => {
    const grok = await translateWithXai(data);
    if (grok?.ok) return grok;
    try {
      return await translateWithChrome(data);
    } catch {
      return { ok: false, error: "Could not reach the translator. Try again." };
    }
  });
