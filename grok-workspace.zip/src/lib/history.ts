const HISTORY_KEY = "lisan-history";
const PREFS_KEY = "lisan-prefs";

export type HistoryItem = {
  id: string;
  sourceText: string;
  translation: string;
  source: string;
  target: string;
  tone: string;
  at: number;
};

export type Prefs = {
  source: string;
  target: string;
  tone: "natural" | "formal" | "casual";
  ui: "en" | "ur";
};

export const DEFAULT_PREFS: Prefs = {
  source: "en",
  target: "ur",
  tone: "natural",
  ui: "en",
};

export function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HistoryItem[];
    if (!Array.isArray(parsed)) return [];
    return parsed.slice(0, 40);
  } catch {
    return [];
  }
}

export function saveHistory(items: HistoryItem[]) {
  localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 40)));
}

export function loadPrefs(): Prefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    return {
      source: parsed.source ?? DEFAULT_PREFS.source,
      target: parsed.target ?? DEFAULT_PREFS.target,
      tone:
        parsed.tone === "formal" || parsed.tone === "casual"
          ? parsed.tone
          : "natural",
      ui: parsed.ui === "ur" ? "ur" : "en",
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

export function savePrefs(prefs: Prefs) {
  localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
}
