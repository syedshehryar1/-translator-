import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, Search } from "lucide-react";
import * as Popover from "@radix-ui/react-popover";
import { cn } from "@/lib/utils";
import {
  AUTO,
  LANGUAGES,
  POPULAR_CODES,
  getLanguage,
  type Language,
} from "@/lib/languages";

type Props = {
  value: string;
  onChange: (code: string) => void;
  includeAuto?: boolean;
  align?: "start" | "end";
  searchPlaceholder?: string;
};

export function LanguagePicker({
  value,
  onChange,
  includeAuto = false,
  align = "start",
  searchPlaceholder = "Search languages",
}: Props) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const current = includeAuto && value === "auto" ? AUTO : getLanguage(value);
  const nativeShown = current.native !== current.name && current.code !== "auto";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const pool: Language[] = includeAuto ? [AUTO, ...LANGUAGES] : LANGUAGES;
    if (!q) return pool;
    return pool.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.native.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q),
    );
  }, [query, includeAuto]);

  const popular = includeAuto
    ? [AUTO, ...POPULAR_CODES.map((c) => getLanguage(c))]
    : POPULAR_CODES.map((c) => getLanguage(c));

  const rest = useMemo(() => {
    const popularCodes = new Set(popular.map((l) => l.code));
    const pool: Language[] = includeAuto ? [AUTO, ...LANGUAGES] : LANGUAGES;
    return pool.filter((l) => !popularCodes.has(l.code));
  }, [includeAuto, popular]);

  useEffect(() => {
    if (open) {
      setQuery("");
      const t = window.setTimeout(() => inputRef.current?.focus(), 30);
      return () => window.clearTimeout(t);
    }
  }, [open]);

  function choose(code: string) {
    onChange(code);
    setOpen(false);
  }

  const list = query ? filtered : null;

  return (
    <Popover.Root open={open} onOpenChange={setOpen}>
      <Popover.Trigger asChild>
        <button
          type="button"
          className={cn(
            "inline-flex h-11 max-w-full min-w-0 items-center gap-2 rounded-xl px-3",
            "text-left text-sm font-medium text-ink",
            "hover:bg-surface-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pine",
            "transition-[background-color,transform] duration-150 ease-out active:scale-[0.96]",
          )}
          aria-label={current.name}
        >
          <span className="flex min-w-0 items-baseline gap-2">
            <span className="truncate">{current.name}</span>
            {nativeShown ? (
              <span
                className={cn(
                  "truncate font-normal text-muted",
                  current.rtl && "font-arabic",
                )}
              >
                {current.native}
              </span>
            ) : null}
          </span>
          <ChevronDown
            className={cn(
              "size-4 shrink-0 text-muted transition-transform duration-150",
              open && "rotate-180",
            )}
            strokeWidth={1.75}
          />
        </button>
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content
          align={align}
          sideOffset={8}
          collisionPadding={12}
          className="z-50 w-80 origin-top rounded-2xl bg-surface p-2 paper-shadow"
        >
          <div className="relative mb-2">
            <Search
              className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-subtle"
              strokeWidth={1.75}
            />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={searchPlaceholder}
              className="h-11 w-full rounded-xl bg-surface-2 ps-10 pe-3 text-sm text-ink outline-none placeholder:text-subtle focus:ring-2 focus:ring-pine/30"
            />
          </div>
          <div className="max-h-72 overflow-y-auto overscroll-contain">
            {list ? (
              list.length === 0 ? (
                <p className="px-3 py-6 text-center text-sm text-muted">
                  No languages match
                </p>
              ) : (
                list.map((lang) => (
                  <LangRow
                    key={lang.code}
                    lang={lang}
                    selected={lang.code === value}
                    onSelect={choose}
                  />
                ))
              )
            ) : (
              <>
                <div className="mb-1 px-2 pt-1 text-xs font-medium tracking-wide text-subtle">
                  Popular
                </div>
                {popular.map((lang) => (
                  <LangRow
                    key={`p-${lang.code}`}
                    lang={lang}
                    selected={lang.code === value}
                    onSelect={choose}
                  />
                ))}
                <div className="mb-1 px-2 pt-2 text-xs font-medium tracking-wide text-subtle">
                  All
                </div>
                {rest.map((lang) => (
                  <LangRow
                    key={lang.code}
                    lang={lang}
                    selected={lang.code === value}
                    onSelect={choose}
                  />
                ))}
              </>
            )}
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}

function LangRow({
  lang,
  selected,
  onSelect,
}: {
  lang: Language;
  selected: boolean;
  onSelect: (code: string) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onSelect(lang.code)}
      className={cn(
        "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-start text-sm transition-colors duration-150",
        selected ? "bg-pine/10 text-ink" : "text-ink hover:bg-surface-2",
      )}
    >
      <span className="min-w-0 flex-1">
        <span className="block truncate font-medium">{lang.name}</span>
        {lang.native !== lang.name ? (
          <span
            className={cn(
              "block truncate text-xs text-muted",
              lang.rtl && "font-arabic",
            )}
            dir={lang.rtl ? "rtl" : "ltr"}
          >
            {lang.native}
          </span>
        ) : (
          <span className="block truncate text-xs text-muted">{lang.code}</span>
        )}
      </span>
      {selected ? (
        <Check className="size-4 shrink-0 text-pine" strokeWidth={2} />
      ) : null}
    </button>
  );
}
