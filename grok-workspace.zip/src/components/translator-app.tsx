import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeftRight,
  Check,
  Copy,
  Eraser,
  History,
  Languages,
  Loader2,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { LanguagePicker } from "@/components/language-picker";
import { translateText } from "@/lib/translate";
import {
  AUTO,
  MAX_CHARS,
  getLanguage,
  type Language,
} from "@/lib/languages";
import {
  DEFAULT_PREFS,
  loadHistory,
  loadPrefs,
  saveHistory,
  savePrefs,
  type HistoryItem,
  type Prefs,
} from "@/lib/history";
import { cn } from "@/lib/utils";

type Tone = Prefs["tone"];

const TONES: { id: Tone; en: string; ur: string }[] = [
  { id: "natural", en: "Natural", ur: "قدرتی" },
  { id: "formal", en: "Formal", ur: "رسمی" },
  { id: "casual", en: "Casual", ur: "دوستانہ" },
];

const COPY = {
  en: {
    translator: "Translator",
    translate: "Translate",
    source: "From",
    target: "To",
    placeholder: "Type or paste text",
    empty: "Translation appears here",
    history: "History",
    emptyHistory: "Your recent translations will live here.",
    copy: "Copy",
    copied: "Copied",
    listen: "Listen",
    stop: "Stop",
    clear: "Clear",
    swap: "Swap languages",
    examples: "Try",
    shortcut: "⌘ Enter",
    shortcutWin: "Ctrl Enter",
    romanization: "Romanization",
    detected: "Detected",
    error: "Something went wrong",
    uiEn: "EN",
    uiUr: "اردو",
    clearHistory: "Clear all",
  },
  ur: {
    translator: "مترجم",
    translate: "ترجمہ کریں",
    source: "سے",
    target: "میں",
    placeholder: "متن لکھیں یا چسپاں کریں",
    empty: "ترجمہ یہاں نظر آئے گا",
    history: "تاریخ",
    emptyHistory: "حالیہ ترجمے یہاں محفوظ ہوں گے۔",
    copy: "کاپی",
    copied: "کاپی ہو گیا",
    listen: "سنیں",
    stop: "روکیں",
    clear: "صاف",
    swap: "زبانیں بدلیں",
    examples: "مثال",
    shortcut: "⌘ Enter",
    shortcutWin: "Ctrl Enter",
    romanization: "رومن",
    detected: "پہچانی گئی",
    error: "ترجمہ نہیں ہو سکا",
    uiEn: "EN",
    uiUr: "اردو",
    clearHistory: "سب مٹائیں",
  },
};

const EXAMPLES: { text: string; source: string; target: string; label: string }[] =
  [
    { text: "How are you?", source: "en", target: "ur", label: "How are you?" },
    {
      text: "آج موسم بہت خوبصورت ہے۔",
      source: "ur",
      target: "en",
      label: "آج موسم…",
    },
    {
      text: "Let's meet tomorrow at five.",
      source: "en",
      target: "hi",
      label: "Let's meet…",
    },
  ];

export function TranslatorApp() {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULT_PREFS);
  const [sourceText, setSourceText] = useState("");
  const [translation, setTranslation] = useState("");
  const [romanization, setRomanization] = useState<string | null>(null);
  const [detected, setDetected] = useState<{ code: string; name: string } | null>(
    null,
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [isMac, setIsMac] = useState(false);

  const requestId = useRef(0);
  const skipNextLangEffect = useRef(true);
  const lastKey = useRef("");
  const cache = useRef(new Map<string, { translation: string; romanization: string | null; detected: { code: string; name: string } }>());

  const t = COPY[prefs.ui];
  const rtlUi = prefs.ui === "ur";
  const sourceLang: Language =
    prefs.source === "auto" ? AUTO : getLanguage(prefs.source);
  const targetLang = getLanguage(prefs.target);

  useEffect(() => {
    setPrefs(loadPrefs());
    setHistory(loadHistory());
    setHydrated(true);
    setIsMac(/Mac|iPhone|iPad/.test(navigator.platform));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    savePrefs(prefs);
  }, [prefs, hydrated]);

  const runTranslate = useCallback(
    async (text: string, source: string, target: string, tone: Tone) => {
      const trimmed = text.trim();
      if (!trimmed) return;
      const key = `${source}|${target}|${tone}|${trimmed}`;
      const cached = cache.current.get(key);
      if (cached) {
        lastKey.current = key;
        setTranslation(cached.translation);
        setRomanization(cached.romanization);
        setDetected(cached.detected);
        setError(null);
        return;
      }
      const id = ++requestId.current;
      setLoading(true);
      setError(null);
      try {
        const result = await translateText({
          data: { text: trimmed, source, target, tone },
        });
        if (id !== requestId.current) return;
        if (!result.ok) {
          setError(result.error);
          return;
        }
        lastKey.current = key;
        cache.current.set(key, {
          translation: result.translation,
          romanization: result.romanization,
          detected: result.detectedSource,
        });
        setTranslation(result.translation);
        setRomanization(result.romanization);
        setDetected(result.detectedSource);
        const item: HistoryItem = {
          id: `${Date.now()}`,
          sourceText: trimmed,
          translation: result.translation,
          source,
          target,
          tone,
          at: Date.now(),
        };
        setHistory((prev) => {
          const next = [
            item,
            ...prev.filter(
              (h) =>
                !(
                  h.sourceText === trimmed &&
                  h.source === source &&
                  h.target === target
                ),
            ),
          ].slice(0, 40);
          saveHistory(next);
          return next;
        });
      } catch {
        if (id !== requestId.current) return;
        setError(COPY[prefs.ui].error);
      } finally {
        if (id === requestId.current) setLoading(false);
      }
    },
    [prefs.ui],
  );

  useEffect(() => {
    if (skipNextLangEffect.current) {
      skipNextLangEffect.current = false;
      return;
    }
    if (!sourceText.trim() || !translation) return;
    void runTranslate(sourceText, prefs.source, prefs.target, prefs.tone);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefs.source, prefs.target, prefs.tone]);

  function updatePrefs(patch: Partial<Prefs>) {
    setPrefs((p) => ({ ...p, ...patch }));
  }

  function onSwap() {
    skipNextLangEffect.current = true;
    const nextSource =
      prefs.source === "auto"
        ? prefs.target
        : prefs.target;
    const nextTarget =
      prefs.source === "auto"
        ? detected?.code && detected.code !== prefs.target
          ? detected.code
          : "en"
        : prefs.source;
    updatePrefs({ source: nextSource, target: nextTarget });
    setSourceText(translation);
    setTranslation(sourceText);
    setRomanization(null);
    setDetected(null);
  }

  function onClear() {
    requestId.current += 1;
    setSourceText("");
    setTranslation("");
    setRomanization(null);
    setDetected(null);
    setError(null);
    setLoading(false);
  }

  async function onCopy() {
    if (!translation) return;
    try {
      await navigator.clipboard.writeText(translation);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  }

  function onSpeak() {
    if (!translation || typeof window === "undefined" || !window.speechSynthesis) {
      return;
    }
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(translation);
    utter.lang = targetLang.bcp47;
    utter.onend = () => setSpeaking(false);
    utter.onerror = () => setSpeaking(false);
    setSpeaking(true);
    window.speechSynthesis.speak(utter);
  }

  function restoreItem(item: HistoryItem) {
    skipNextLangEffect.current = true;
    updatePrefs({
      source: item.source,
      target: item.target,
      tone: item.tone as Tone,
    });
    setSourceText(item.sourceText);
    setTranslation(item.translation);
    setRomanization(null);
    setDetected(null);
    setHistoryOpen(false);
  }

  const shortcut = isMac ? t.shortcut : t.shortcutWin;
  const charCount = sourceText.length;
  const canTranslate = sourceText.trim().length > 0 && !loading;

  const sourceDir = sourceLang.rtl ? "rtl" : "ltr";
  const targetDir = targetLang.rtl ? "rtl" : "ltr";
  const sourceFont = sourceLang.rtl || sourceLang.code === "ur";
  const targetFont = targetLang.rtl || targetLang.code === "ur";

  const detectedLabel = useMemo(() => {
    if (prefs.source !== "auto" || !detected) return null;
    return `${t.detected}: ${detected.name}`;
  }, [prefs.source, detected, t.detected]);

  return (
    <div
      dir={rtlUi ? "rtl" : "ltr"}
      className="relative mx-auto flex min-h-dvh max-w-6xl flex-col px-4 pb-16 pt-6 sm:px-6 sm:pt-10"
    >
      <header className="enter-up mb-8 flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="flex size-11 items-center justify-center rounded-xl bg-pine text-pine-fg">
            <Languages className="size-5" strokeWidth={1.75} />
          </span>
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="font-display text-3xl font-medium tracking-tight text-ink italic">
                Lisan
              </h1>
              <span className="font-arabic text-lg text-muted" dir="rtl">
                لسان
              </span>
            </div>
            <p className="text-sm text-muted">{t.translator}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <div className="flex rounded-xl bg-surface-2 p-1">
            <button
              type="button"
              onClick={() => updatePrefs({ ui: "en" })}
              className={cn(
                "h-9 rounded-lg px-3 text-xs font-medium transition-colors duration-150",
                prefs.ui === "en"
                  ? "bg-surface text-ink paper-shadow"
                  : "text-muted hover:text-ink",
              )}
            >
              {t.uiEn}
            </button>
            <button
              type="button"
              onClick={() => updatePrefs({ ui: "ur" })}
              className={cn(
                "h-9 rounded-lg px-3 font-arabic text-xs font-medium transition-colors duration-150",
                prefs.ui === "ur"
                  ? "bg-surface text-ink paper-shadow"
                  : "text-muted hover:text-ink",
              )}
            >
              {t.uiUr}
            </button>
          </div>
          <Button
            variant="ghost"
            size="icon"
            aria-label={t.history}
            onClick={() => setHistoryOpen(true)}
          >
            <History className="size-5" strokeWidth={1.75} />
          </Button>
        </div>
      </header>

      <div className="enter-up enter-up-delay-1 mb-4 flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-subtle">
          {t.examples}
        </span>
        {EXAMPLES.map((ex) => (
          <button
            key={ex.label}
            type="button"
            onClick={() => {
              skipNextLangEffect.current = true;
              updatePrefs({ source: ex.source, target: ex.target });
              setSourceText(ex.text);
              void runTranslate(ex.text, ex.source, ex.target, prefs.tone);
            }}
            className="h-9 rounded-full bg-surface px-3.5 text-sm text-ink paper-shadow transition-[transform,box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
          >
            {ex.label}
          </button>
        ))}
      </div>

      <div className="enter-up enter-up-delay-2 relative grid grid-cols-1 gap-3 lg:grid-cols-[1fr_auto_1fr] lg:items-stretch">
        <section className="flex min-h-72 flex-col rounded-2xl bg-surface p-3 paper-shadow sm:min-h-80 sm:p-4">
          <div className="mb-2 flex items-center justify-between gap-2">
            <LanguagePicker
              value={prefs.source}
              includeAuto
              searchPlaceholder={rtlUi ? "زبان تلاش کریں" : "Search languages"}
              onChange={(code) => {
                if (code === prefs.target) return;
                updatePrefs({ source: code });
              }}
            />
            {detectedLabel ? (
              <span className="truncate pe-2 text-xs text-muted">
                {detectedLabel}
              </span>
            ) : null}
          </div>
          <textarea
            value={sourceText}
            maxLength={MAX_CHARS}
            onChange={(e) => setSourceText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                if (canTranslate) {
                  void runTranslate(
                    sourceText,
                    prefs.source,
                    prefs.target,
                    prefs.tone,
                  );
                }
              }
            }}
            placeholder={t.placeholder}
            dir={sourceDir}
            className={cn(
              "min-h-44 flex-1 resize-none bg-transparent px-2 py-2 text-lg leading-relaxed text-ink outline-none placeholder:text-subtle",
              sourceFont && "font-arabic",
            )}
          />
          <div className="mt-2 flex items-center justify-between gap-2 px-1">
            <span className="tabular-nums text-xs text-subtle">
              {charCount} / {MAX_CHARS}
            </span>
            <button
              type="button"
              onClick={onClear}
              disabled={!sourceText}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg px-2 text-xs font-medium text-muted transition-colors hover:text-ink disabled:opacity-40"
            >
              <Eraser className="size-3.5" strokeWidth={1.75} />
              {t.clear}
            </button>
          </div>
        </section>

        <div className="flex items-center justify-center gap-3 lg:flex-col">
          <Button
            variant="outline"
            size="icon"
            aria-label={t.swap}
            onClick={onSwap}
            className="bg-surface"
          >
            <ArrowLeftRight className="size-4 lg:rotate-90" strokeWidth={1.75} />
          </Button>
        </div>

        <section className="flex min-h-72 flex-col rounded-2xl bg-surface p-3 paper-shadow sm:min-h-80 sm:p-4">
          <div className="mb-2 flex items-center justify-between gap-2">
            <LanguagePicker
              value={prefs.target}
              align="end"
              searchPlaceholder={rtlUi ? "زبان تلاش کریں" : "Search languages"}
              onChange={(code) => {
                if (code === prefs.source && prefs.source !== "auto") return;
                updatePrefs({ target: code });
              }}
            />
          </div>
          <div className="relative min-h-44 flex-1 px-2 py-2">
            {loading ? (
              <div className="space-y-3 pt-2">
                <div className="shimmer h-3 w-5/6 rounded-full" />
                <div className="shimmer h-3 w-2/3 rounded-full" />
                <div className="shimmer h-3 w-3/4 rounded-full" />
              </div>
            ) : translation ? (
              <p
                dir={targetDir}
                className={cn(
                  "whitespace-pre-wrap text-lg leading-relaxed text-ink",
                  targetFont && "font-arabic",
                )}
              >
                {translation}
              </p>
            ) : (
              <p className="text-lg text-subtle">{t.empty}</p>
            )}
            {error ? (
              <p className="mt-3 text-sm text-danger">{error}</p>
            ) : null}
            {romanization && !loading ? (
              <p className="mt-4 text-sm italic leading-relaxed text-muted">
                <span className="not-italic tracking-wide text-subtle uppercase">
                  {t.romanization}
                </span>
                <span className="mx-2 text-line">/</span>
                {romanization}
              </p>
            ) : null}
          </div>
          <div className="mt-2 flex items-center justify-end gap-1 px-1">
            <Button
              variant="ghost"
              size="iconSm"
              aria-label={speaking ? t.stop : t.listen}
              disabled={!translation}
              onClick={onSpeak}
            >
              {speaking ? (
                <VolumeX className="size-4" strokeWidth={1.75} />
              ) : (
                <Volume2 className="size-4" strokeWidth={1.75} />
              )}
            </Button>
            <Button
              variant="ghost"
              size="iconSm"
              aria-label={copied ? t.copied : t.copy}
              disabled={!translation}
              onClick={onCopy}
            >
              {copied ? (
                <Check className="size-4 text-ok" strokeWidth={2} />
              ) : (
                <Copy className="size-4" strokeWidth={1.75} />
              )}
            </Button>
          </div>
        </section>
      </div>

      <div className="enter-up enter-up-delay-3 mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex rounded-xl bg-surface-2 p-1">
          {TONES.map((tone) => (
            <button
              key={tone.id}
              type="button"
              onClick={() => updatePrefs({ tone: tone.id })}
              className={cn(
                "h-10 min-w-20 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
                prefs.tone === tone.id
                  ? "bg-surface text-ink paper-shadow"
                  : "text-muted hover:text-ink",
              )}
            >
              {rtlUi ? tone.ur : tone.en}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden text-xs text-subtle sm:inline">{shortcut}</span>
          <Button
            size="lg"
            disabled={!canTranslate}
            onClick={() =>
              void runTranslate(
                sourceText,
                prefs.source,
                prefs.target,
                prefs.tone,
              )
            }
            className="min-w-40"
          >
            {loading ? (
              <Loader2 className="size-4 animate-spin" strokeWidth={1.75} />
            ) : null}
            {t.translate}
          </Button>
        </div>
      </div>

      {historyOpen ? (
        <div className="fixed inset-0 z-50 flex justify-end">
          <button
            type="button"
            className="absolute inset-0 bg-ink/20"
            aria-label="Close history"
            onClick={() => setHistoryOpen(false)}
          />
          <aside
            className="relative flex h-full w-full max-w-md flex-col bg-bg p-5 shadow-[var(--shadow-border)]"
            role="dialog"
            aria-label={t.history}
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-2xl italic">{t.history}</h2>
              <div className="flex items-center gap-1">
                {history.length > 0 ? (
                  <button
                    type="button"
                    className="h-11 px-3 text-sm text-muted hover:text-ink"
                    onClick={() => {
                      setHistory([]);
                      saveHistory([]);
                    }}
                  >
                    {t.clearHistory}
                  </button>
                ) : null}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setHistoryOpen(false)}
                  aria-label="Close"
                >
                  <X className="size-5" strokeWidth={1.75} />
                </Button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {history.length === 0 ? (
                <p className="py-12 text-sm text-muted">{t.emptyHistory}</p>
              ) : (
                <ul className="space-y-2">
                  {history.map((item) => {
                    const from = getLanguage(item.source);
                    const to = getLanguage(item.target);
                    return (
                      <li key={item.id}>
                        <button
                          type="button"
                          onClick={() => restoreItem(item)}
                          className="w-full rounded-2xl bg-surface p-4 text-start paper-shadow transition-[transform,box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
                        >
                          <div className="mb-2 text-xs text-subtle">
                            {from.name} → {to.name}
                          </div>
                          <p className="line-clamp-2 text-sm text-ink">
                            {item.sourceText}
                          </p>
                          <p
                            className={cn(
                              "mt-1 line-clamp-2 text-sm text-muted",
                              to.rtl && "font-arabic",
                            )}
                            dir={to.rtl ? "rtl" : "ltr"}
                          >
                            {item.translation}
                          </p>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </aside>
        </div>
      ) : null}
    </div>
  );
}
